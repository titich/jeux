create definer = jeux@`%` view v_stats as
select avg(`jeux`.`jeu`.`jeu_bgg_numplays`) AS `moy_nb_partie_jouee`
from `jeux`.`jeu`
where `jeux`.`jeu`.`jeu_bgg_own` = 1
  and `jeux`.`jeu`.`jeu_bgg_subtype` = 'boardgame';

