create view v_family_categories as
select left(`jeux`.`family`.`family_nom_en`, locate(':', `jeux`.`family`.`family_nom_en`) - 1) AS `family_group`,
       count(0)                                                                                AS `nbre`
from `jeux`.`family`
group by left(`jeux`.`family`.`family_nom_en`, locate(':', `jeux`.`family`.`family_nom_en`) - 1)
order by count(0) desc;

