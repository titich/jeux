create view v_family_cut as
select substring_index(`jeux`.`family`.`family_nom_en`, ':', 1)  AS `cat`,
       substring_index(`jeux`.`family`.`family_nom_en`, ':', -1) AS `sous_cat`
from `jeux`.`family`
where `jeux`.`family`.`family_nom_en` is not null
order by substring_index(`jeux`.`family`.`family_nom_en`, ':', 1),
         substring_index(`jeux`.`family`.`family_nom_en`, ':', -1);

