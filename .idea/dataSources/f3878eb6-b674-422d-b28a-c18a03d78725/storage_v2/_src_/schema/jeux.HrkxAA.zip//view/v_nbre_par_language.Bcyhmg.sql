create definer = jeux@localhost view v_nbre_par_language as
select `jeux`.`language_jeu`.`language`    AS `language_id`,
       `jeux`.`language`.`language_nom_en` AS `language_nom_en`,
       count(0)                            AS `nbre`
from ((`jeux`.`language_jeu` left join `jeux`.`language` on (`jeux`.`language`.`language_id` = `jeux`.`language_jeu`.`language`))
         left join `jeux`.`jeu` on (`jeux`.`jeu`.`jeu_id` = `jeux`.`language_jeu`.`jeu`))
where `jeux`.`jeu`.`jeu_bgg_subtype` = 'boardgame'
group by `jeux`.`language_jeu`.`language`, `jeux`.`language`.`language_nom_en`
order by count(0) desc;

