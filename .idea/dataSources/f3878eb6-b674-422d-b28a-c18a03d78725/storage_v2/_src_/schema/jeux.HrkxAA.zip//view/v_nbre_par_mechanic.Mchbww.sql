create definer = jeux@localhost view v_nbre_par_mechanic as
select `jeux`.`mechanic_jeu`.`mechanic`    AS `mechanic_id`,
       `jeux`.`mechanic`.`mechanic_nom_en` AS `mechanic_nom_en`,
       count(0)                            AS `nbre`
from ((`jeux`.`mechanic_jeu` left join `jeux`.`mechanic` on (`jeux`.`mechanic`.`mechanic_id` = `jeux`.`mechanic_jeu`.`mechanic`))
         left join `jeux`.`jeu` on (`jeux`.`jeu`.`jeu_id` = `jeux`.`mechanic_jeu`.`jeu`))
where `jeux`.`jeu`.`jeu_bgg_subtype` = 'boardgame'
group by `jeux`.`mechanic_jeu`.`mechanic`, `jeux`.`mechanic`.`mechanic_nom_en`
order by count(0) desc;

