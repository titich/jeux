create definer = jeux@`%` view v_moyenne_votes as
select avg(`jeux`.`jeu`.`jeu_bgg_nb_player_nb_votes`)           AS `moy_vote_nb_player`,
       avg(`jeux`.`jeu`.`jeu_bgg_averageweight_nb_vote`)        AS `moy_vote_averageweight`,
       avg(`jeux`.`jeu`.`jeu_bgg_note_nb_vote`)                 AS `moy_vote_note`,
       avg(`jeux`.`jeu`.`jeu_bgg_suggested_playerage_nb_votes`) AS `moy_vote_suggested_playerage`
from `jeux`.`jeu`;

