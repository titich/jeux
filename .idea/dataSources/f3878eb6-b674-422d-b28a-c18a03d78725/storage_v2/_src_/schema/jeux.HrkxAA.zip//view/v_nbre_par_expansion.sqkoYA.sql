create view v_nbre_par_expansion as
select `jeux`.`expansion_jeu`.`expansion`    AS `expansion_id`,
       `jeux`.`expansion`.`expansion_nom_en` AS `expansion_nom_en`,
       count(0)                              AS `nbre`
from ((`jeux`.`expansion_jeu` left join `jeux`.`expansion` on (`jeux`.`expansion`.`expansion_id` =
                                                               `jeux`.`expansion_jeu`.`expansion`))
         left join `jeux`.`jeu` on (`jeux`.`jeu`.`jeu_id` = `jeux`.`expansion_jeu`.`jeu`))
where `jeux`.`jeu`.`jeu_bgg_subtype` = 'boardgame'
group by `jeux`.`expansion_jeu`.`expansion`, `jeux`.`expansion`.`expansion_nom_en`
order by count(0) desc;

