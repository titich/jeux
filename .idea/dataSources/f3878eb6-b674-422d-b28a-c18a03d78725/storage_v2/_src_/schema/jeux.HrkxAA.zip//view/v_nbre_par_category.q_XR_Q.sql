create view v_nbre_par_category as
select `jeux`.`category_jeu`.`category`    AS `category_id`,
       `jeux`.`category`.`category_nom_en` AS `category_nom_en`,
       count(0)                            AS `nbre`
from ((`jeux`.`category_jeu` left join `jeux`.`category` on (`jeux`.`category`.`category_id` = `jeux`.`category_jeu`.`category`))
         left join `jeux`.`jeu` on (`jeux`.`jeu`.`jeu_id` = `jeux`.`category_jeu`.`jeu`))
where `jeux`.`jeu`.`jeu_bgg_subtype` = 'boardgame'
group by `jeux`.`category_jeu`.`category`, `jeux`.`category`.`category_nom_en`
order by count(0) desc;

