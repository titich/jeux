create definer = jeux@`%` view v_nb_cat as
select sum(`jeux`.`jeu`.`jeu_bgg_own`)        AS `nb_own`,
       sum(`jeux`.`jeu`.`jeu_est_pret`)       AS `jeu_est_pret`,
       sum(`jeux`.`jeu`.`jeu_bgg_preordered`) AS `nb_preordered`,
       sum(`jeux`.`jeu`.`jeu_bgg_prevowned`)  AS `nb_prevowned`,
       sum(`jeux`.`jeu`.`jeu_bgg_fortrade`)   AS `nb_fortrade`,
       sum(`jeux`.`jeu`.`jeu_bgg_want`)       AS `nb_want`,
       sum(`jeux`.`jeu`.`jeu_bgg_wanttoplay`) AS `nb_wanttoplay`,
       sum(`jeux`.`jeu`.`jeu_bgg_wanttobuy`)  AS `nb_wanttobuy`,
       sum(`jeux`.`jeu`.`jeu_bgg_wishlist`)   AS `nb_wishlist`
from `jeux`.`jeu`
where `jeux`.`jeu`.`jeu_bgg_subtype` = 'boardgame';

