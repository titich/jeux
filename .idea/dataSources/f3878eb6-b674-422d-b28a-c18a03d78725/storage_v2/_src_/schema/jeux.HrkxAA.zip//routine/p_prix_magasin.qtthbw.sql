create
    definer = jeux@`%` procedure p_prix_magasin()
BEGIN

	SELECT @USD:=`cours_actuel_USD`,@EUR:=`cours_actuel_EUR`,@AUD:=`cours_actuel_AUD`
	FROM `cours_actuel` 
	ORDER BY `cours_actuel`.`cours_actuel_date`  DESC
	LIMIT 0,1;
	
	TRUNCATE TABLE `r_prix_magasin`;
	
	INSERT INTO `r_prix_magasin` (`jeu_bgstats_AcquiredFrom`, `nb`, `prix_CHF`, `prix_CHF_moyen`) 
	SELECT `jeu_bgstats_AcquiredFrom`,`nb`,`prix_CHF`
	,(`prix_CHF`/`nb`) AS `prix_CHF_moyen`
	FROM (
		SELECT `jeu_bgstats_AcquiredFrom`,SUM(`prix_CHF`) as `prix_CHF`,SUM(`nb`) as `nb`
		FROM(
			SELECT 
			CASE
				WHEN `jeu_bgstats_PricePaidCurrency` = 'USD' THEN `prix`/@USD
				WHEN `jeu_bgstats_PricePaidCurrency` = 'AUD' THEN `prix`/@AUD
				WHEN `jeu_bgstats_PricePaidCurrency` = 'EUR' THEN `prix`/@EUR
				ELSE `prix`
			END as `prix_CHF`
			,`jeu_bgstats_AcquiredFrom`,`nb`,`prix`,`jeu_bgstats_PricePaidCurrency`
			FROM (
				SELECT
					`jeu_bgstats_AcquiredFrom`,
					COUNT(0) AS `nb`,
					SUM(`jeu_bgstats_PricePaid`) AS `prix`,
					`jeu_bgstats_PricePaidCurrency` AS `jeu_bgstats_PricePaidCurrency`
				FROM
					`jeu`
				WHERE 
					`jeu_bgg_own` = 1
				GROUP BY
					`jeu_bgstats_AcquiredFrom`,
					`jeu_bgstats_PricePaidCurrency`
			) as a
		) as b
		GROUP BY `jeu_bgstats_AcquiredFrom`
	) as c
	ORDER BY `prix_CHF` DESC;
	

END;

