create view v_erreur_media as
select `jeux`.`jeu_media`.`jeu_media_id`                                                               AS `jeu_media_id`,
       `jeux`.`jeu_media`.`jeu`                                                                        AS `jeu`,
       `jeux`.`jeu_media`.`jeu_media_type`                                                             AS `jeu_media_type`,
       `jeux`.`jeu_media`.`jeu_media_dossier`                                                          AS `jeu_media_dossier`,
       `jeux`.`jeu_media`.`jeu_media_fichier`                                                          AS `jeu_media_fichier`,
       `jeux`.`jeu_media`.`jeu_media_MIME`                                                             AS `jeu_media_MIME`,
       `jeux`.`jeu_media`.`jeu_media_taille`                                                           AS `jeu_media_taille`,
       `jeux`.`jeu_media`.`jeu_media_extention`                                                        AS `jeu_media_extention`,
       `jeux`.`jeu_media`.`jeu_media_lien`                                                             AS `jeu_media_lien`,
       octet_length(`jeux`.`jeu_media`.`jeu_media_dossier`)                                            AS `LENGTH(``jeu_media_dossier``)`,
       octet_length(`jeux`.`jeu_media`.`jeu_media_fichier`)                                            AS `LENGTH(``jeu_media_fichier``)`,
       case when right(`jeux`.`jeu_media`.`jeu_media_dossier`, 1) <> '/' then 'pas de /' else 'OK' end AS `erreur`
from `jeux`.`jeu_media`
where case when right(`jeux`.`jeu_media`.`jeu_media_dossier`, 1) <> '/' then 'pas de /' else 'OK' end <> 'OK'
order by `jeux`.`jeu_media`.`jeu_media_fichier`;

