create view v_avancement as
select 'poids'                   AS `quoi`,
       `b`.`nbre_tot` - count(0) AS `nbre_fait`,
       count(0)                  AS `nbre_a_faire`,
       `b`.`nbre_tot`            AS `nbre_tot`
from (`jeux`.`jeu`
         left join (select count(0) AS `nbre_tot`
                    from `jeux`.`jeu`
                    where `jeux`.`jeu`.`jeu_est_boite` = 1
                      and `jeux`.`jeu`.`jeu_bgg_own` = 1) `b` on (1))
where (`jeux`.`jeu`.`jeu_x` is null or `jeux`.`jeu`.`jeu_y` is null or `jeux`.`jeu`.`jeu_z` is null or
       `jeux`.`jeu`.`jeu_poids` is null)
  and `jeux`.`jeu`.`jeu_est_boite` = 1
  and `jeux`.`jeu`.`jeu_bgg_own` = 1
union all
select 'description'                 AS `quoi`,
       count(0) - `a`.`nbre_a_faire` AS `nbre_fait`,
       `a`.`nbre_a_faire`            AS `nbre_a_faire`,
       count(0)                      AS `nbre_tot`
from (`jeux`.`jeu`
         join (select count(0) AS `nbre_a_faire`
               from `jeux`.`jeu`
               where `jeux`.`jeu`.`jeu_description_fr_update_date` < `jeux`.`jeu`.`jeu_bgg_description_update_date`
                  or `jeux`.`jeu`.`jeu_description_fr` is null) `a` on (1))
where `jeux`.`jeu`.`jeu_bgg_description` is not null;

