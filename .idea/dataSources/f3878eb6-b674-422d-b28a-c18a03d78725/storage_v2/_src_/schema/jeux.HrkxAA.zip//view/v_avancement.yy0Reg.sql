create definer = jeux@localhost view v_avancement as
select 'poids'                   AS `quoi`,
       `b`.`nbre_tot` - count(0) AS `nbre_fait`,
       count(0)                  AS `nbre_a_faire`,
       `b`.`nbre_tot`            AS `nbre_tot`,
       '1'                       AS `affichage`
from (`jeux`.`jeu`
         left join (select count(0) AS `nbre_tot`
                    from `jeux`.`jeu`
                    where `jeux`.`jeu`.`jeu_est_boite` = 1
                      and `jeux`.`jeu`.`jeu_bgg_own` = 1) `b` on (1))
where (`jeux`.`jeu`.`jeu_x` is null or `jeux`.`jeu`.`jeu_y` is null or `jeux`.`jeu`.`jeu_z` is null or
       `jeux`.`jeu`.`jeu_poids` is null)
  and `jeux`.`jeu`.`jeu_est_boite` = 1
  and `jeux`.`jeu`.`jeu_bgg_own` = 1
union
select 'description'                 AS `quoi`,
       count(0) - `a`.`nbre_a_faire` AS `nbre_fait`,
       `a`.`nbre_a_faire`            AS `nbre_a_faire`,
       count(0)                      AS `nbre_tot`,
       '1'                           AS `affichage`
from (`jeux`.`jeu`
         join (select count(0) AS `nbre_a_faire`
               from `jeux`.`jeu`
               where `jeux`.`jeu`.`jeu_description_fr_update_date` < `jeux`.`jeu`.`jeu_bgg_description_update_date`
                  or `jeux`.`jeu`.`jeu_description_fr` is null) `a` on (1))
where `jeux`.`jeu`.`jeu_bgg_description` is not null
union
select 'regles'                      AS `quoi`,
       count(0) - `c`.`nbre_a_faire` AS `nbre_fait`,
       `c`.`nbre_a_faire`            AS `nbre_a_faire`,
       count(0)                      AS `nbre_tot`,
       '0'                           AS `affichage`
from (`jeux`.`jeu`
         join (select count(0) AS `nbre_a_faire`
               from (select `jeux`.`jeu`.`jeu_id` AS `jeu_id`, `jeux`.`jeu`.`jeu_nom` AS `jeu_nom`
                     from (`jeux`.`jeu`
                              left join `jeux`.`jeu_media` on (`jeux`.`jeu_media`.`jeu` = `jeux`.`jeu`.`jeu_id` and
                                                               `jeux`.`jeu_media`.`jeu_media_type` = 1))
                     where `jeux`.`jeu_media`.`jeu_media_type` is null
                     group by `jeux`.`jeu`.`jeu_id`) `d`) `c` on (1))
where 1
union
select 'regles 2'                    AS `quoi`,
       count(0) - `c`.`nbre_a_faire` AS `nbre_fait`,
       `c`.`nbre_a_faire`            AS `nbre_a_faire`,
       count(0)                      AS `nbre_tot`,
       '1'                           AS `affichage`
from (`jeux`.`jeu_media`
         join (select count(0) AS `nbre_a_faire`
               from (select `jeux`.`jeu`.`jeu_id` AS `jeu_id`, `jeux`.`jeu`.`jeu_nom` AS `jeu_nom`
                     from (`jeux`.`jeu`
                              left join `jeux`.`jeu_media` on (`jeux`.`jeu_media`.`jeu` = `jeux`.`jeu`.`jeu_id`))
                     where `jeux`.`jeu_media`.`jeu_media_type` is not null
                       and (`jeux`.`jeu_media`.`jeu_media_a_imprimer` is null or
                            `jeux`.`jeu_media`.`jeu_media_officiel` is null or
                            `jeux`.`jeu_media`.`language` is null)) `d`) `c` on (1))
where 1;

