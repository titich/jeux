create definer = jeux@localhost view v_jeu_stats_jeu as
select `jeux`.`jeu`.`jeu_id`                                                                                 AS `jeu_id`,
       `jeux`.`jeu`.`jeu_nom`                                                                                AS `jeu_nom`,
       `jeux`.`jeu`.`jeu_x`                                                                                  AS `jeu_x`,
       `jeux`.`jeu`.`jeu_y`                                                                                  AS `jeu_y`,
       `jeux`.`jeu`.`jeu_z`                                                                                  AS `jeu_z`,
       `jeux`.`jeu`.`jeu_poids`                                                                              AS `jeu_poids`,
       `jeux`.`jeu`.`jeu_est_boite`                                                                          AS `jeu_est_boite`,
       `jeux`.`jeu`.`jeu_x` * `jeux`.`jeu`.`jeu_y` * `jeux`.`jeu`.`jeu_z`                                    AS `jeu_volume`,
       `v_jeu_stats_global`.`poids_mm3`                                                                      AS `poids_mm3`,
       `jeux`.`jeu`.`jeu_poids` - `jeux`.`jeu`.`jeu_x` * `jeux`.`jeu`.`jeu_y` * `jeux`.`jeu`.`jeu_z` *
                                  `v_jeu_stats_global`.`poids_mm3`                                           AS `diff_moyenne`,
       `jeux`.`jeu`.`jeu_x` * `jeux`.`jeu`.`jeu_y` * `jeux`.`jeu`.`jeu_z` *
       `v_jeu_stats_global`.`poids_mm3`                                                                      AS `poids_calc_selon_moy`,
       case
           when `jeux`.`jeu`.`jeu_x` * `jeux`.`jeu`.`jeu_y` * `jeux`.`jeu`.`jeu_z` * `v_jeu_stats_global`.`poids_mm3` >
                `jeux`.`jeu`.`jeu_poids` then 1
           else 0 end                                                                                        AS `jeu_leger`,
       case
           when `jeux`.`jeu`.`jeu_x` * `jeux`.`jeu`.`jeu_y` * `jeux`.`jeu`.`jeu_z` < `v_jeu_stats_global`.`volume_bas`
               then 'petit'
           when `jeux`.`jeu`.`jeu_x` * `jeux`.`jeu`.`jeu_y` * `jeux`.`jeu`.`jeu_z` >=
                `v_jeu_stats_global`.`volume_bas` and
                `jeux`.`jeu`.`jeu_x` * `jeux`.`jeu`.`jeu_y` * `jeux`.`jeu`.`jeu_z` <= `v_jeu_stats_global`.`volume_haut`
               then 'moyen'
           else 'gros' end                                                                                   AS `taille_jeu`
from (`jeux`.`jeu`
         left join `jeux`.`v_jeu_stats_global` on (1))
where `jeux`.`jeu`.`jeu_x` is not null
  and `jeux`.`jeu`.`jeu_y` is not null
  and `jeux`.`jeu`.`jeu_z` is not null
  and `jeux`.`jeu`.`jeu_poids` is not null;

