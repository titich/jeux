create definer = jeux@localhost view v_jeu_stats_global as
select `b`.`poids_tot`                                              AS `poids_tot`,
       `b`.`volume_tot`                                             AS `volume_tot_mm3`,
       `b`.`volume_tot` / 1000000000                                AS `volume_tot_m3`,
       `b`.`poids_tot` / `b`.`volume_tot`                           AS `poids_mm3`,
       `b`.`volume_min`                                             AS `volume_min`,
       (`b`.`volume_moy` - `b`.`volume_min`) / 2 + `b`.`volume_min` AS `volume_bas`,
       `b`.`volume_moy`                                             AS `volume_moy_mm3`,
       (`b`.`volume_max` - `b`.`volume_moy`) / 2 + `b`.`volume_moy` AS `volume_haut`,
       `b`.`volume_max`                                             AS `volume_max`,
       `b`.`nbre`                                                   AS `nbre`
from (select sum(`a`.`jeu_poids`)  AS `poids_tot`,
             sum(`a`.`jeu_volume`) AS `volume_tot`,
             avg(`a`.`jeu_volume`) AS `volume_moy`,
             min(`a`.`jeu_volume`) AS `volume_min`,
             max(`a`.`jeu_volume`) AS `volume_max`,
             count(0)              AS `nbre`
      from (select `jeux`.`jeu`.`jeu_id`                                              AS `jeu_id`,
                   `jeux`.`jeu`.`jeu_nom`                                             AS `jeu_nom`,
                   `jeux`.`jeu`.`jeu_x`                                               AS `jeu_x`,
                   `jeux`.`jeu`.`jeu_y`                                               AS `jeu_y`,
                   `jeux`.`jeu`.`jeu_z`                                               AS `jeu_z`,
                   `jeux`.`jeu`.`jeu_poids`                                           AS `jeu_poids`,
                   `jeux`.`jeu`.`jeu_est_boite`                                       AS `jeu_est_boite`,
                   `jeux`.`jeu`.`jeu_x` * `jeux`.`jeu`.`jeu_y` * `jeux`.`jeu`.`jeu_z` AS `jeu_volume`
            from `jeux`.`jeu`
            where `jeux`.`jeu`.`jeu_x` is not null
              and `jeux`.`jeu`.`jeu_y` is not null
              and `jeux`.`jeu`.`jeu_z` is not null
              and `jeux`.`jeu`.`jeu_poids` is not null) `a`) `b`;

