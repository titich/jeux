create view v_prix_magasin as
select `jeux`.`jeu`.`jeu_bgstats_AcquiredFrom`      AS `jeu_bgstats_AcquiredFrom`,
       count(0)                                     AS `nb`,
       sum(`jeux`.`jeu`.`jeu_bgstats_PricePaid`)    AS `prix`,
       `jeux`.`jeu`.`jeu_bgstats_PricePaidCurrency` AS `jeu_bgstats_PricePaidCurrency`
from `jeux`.`jeu`
where 1
group by `jeux`.`jeu`.`jeu_bgstats_AcquiredFrom`, `jeux`.`jeu`.`jeu_bgstats_PricePaidCurrency`
order by count(0) desc;

