create definer = jeux@localhost view v_nbre_par_boardgamepublisher as
select `jeux`.`boardgamepublisher_jeu`.`boardgamepublisher`    AS `boardgamepublisher_id`,
       `jeux`.`boardgamepublisher`.`boardgamepublisher_nom_en` AS `boardgamepublisher_nom_en`,
       count(0)                                                AS `nbre`
from ((`jeux`.`boardgamepublisher_jeu` left join `jeux`.`boardgamepublisher` on (
        `jeux`.`boardgamepublisher`.`boardgamepublisher_id` = `jeux`.`boardgamepublisher_jeu`.`boardgamepublisher`))
         left join `jeux`.`jeu` on (`jeux`.`jeu`.`jeu_id` = `jeux`.`boardgamepublisher_jeu`.`jeu`))
where `jeux`.`jeu`.`jeu_bgg_subtype` = 'boardgame'
group by `jeux`.`boardgamepublisher_jeu`.`boardgamepublisher`, `jeux`.`boardgamepublisher`.`boardgamepublisher_nom_en`
order by count(0) desc;

