create view v_coolitude as
select `jeux`.`jeu`.`jeu_id`        AS `jeu_id`,
       `jeux`.`jeu`.`jeu_nom`       AS `jeu_nom`,
       `jeux`.`jeu`.`jeu_coolitude` AS `jeu_coolitude`
from `jeux`.`jeu`
where `jeux`.`jeu`.`jeu_coolitude` is not null
order by `jeux`.`jeu`.`jeu_coolitude`;

