create definer = jeux@localhost view v_nbre_par_family as
select `jeux`.`family_jeu`.`family`    AS `family_id`,
       `jeux`.`family`.`family_nom_en` AS `family_nom_en`,
       count(0)                        AS `nbre`
from ((`jeux`.`family_jeu` left join `jeux`.`family` on (`jeux`.`family`.`family_id` = `jeux`.`family_jeu`.`family`))
         left join `jeux`.`jeu` on (`jeux`.`jeu`.`jeu_id` = `jeux`.`family_jeu`.`jeu`))
where `jeux`.`jeu`.`jeu_bgg_subtype` = 'boardgame'
group by `jeux`.`family_jeu`.`family`, `jeux`.`family`.`family_nom_en`
order by count(0) desc;

