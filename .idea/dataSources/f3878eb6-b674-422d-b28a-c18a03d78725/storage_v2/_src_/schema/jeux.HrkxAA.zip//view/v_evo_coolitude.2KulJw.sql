create view v_evo_coolitude as
select `a`.`jeu`                 AS `jeu`,
       `a`.`jeu_nom`             AS `jeu_nom`,
       count(0)                  AS `nbre`,
       sum(`a`.`sum`)            AS `SUM(``sum``)`,
       sum(`a`.`sum`) / count(0) AS `classement`
from (select `jeux`.`evolution_note`.`jeu` AS `jeu`,
             `jeux`.`jeu`.`jeu_nom`        AS `jeu_nom`,
             case
                 when `jeux`.`evolution_note`.`evolution_note_de` = 0 then 1
                 else (`jeux`.`evolution_note`.`evolution_note_a` - `jeux`.`evolution_note`.`evolution_note_de`) *
                      -1 end               AS `sum`
      from (`jeux`.`evolution_note`
               left join `jeux`.`jeu` on (`jeux`.`jeu`.`jeu_id` = `jeux`.`evolution_note`.`jeu`))
      where `jeux`.`evolution_note`.`evolution_note_type` = 7) `a`
group by `a`.`jeu`
having `nbre` > 1
order by count(0) desc;

