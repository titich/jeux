create definer = jeux@localhost view v_nbre_par_designer as
select `jeux`.`designer_jeu`.`designer`    AS `designer_id`,
       `jeux`.`designer`.`designer_nom_en` AS `designer_nom_en`,
       count(0)                            AS `nbre`
from ((`jeux`.`designer_jeu` left join `jeux`.`designer` on (`jeux`.`designer`.`designer_id` = `jeux`.`designer_jeu`.`designer`))
         left join `jeux`.`jeu` on (`jeux`.`jeu`.`jeu_id` = `jeux`.`designer_jeu`.`jeu`))
where `jeux`.`jeu`.`jeu_bgg_subtype` = 'boardgame'
group by `jeux`.`designer_jeu`.`designer`, `jeux`.`designer`.`designer_nom_en`
order by count(0) desc;

