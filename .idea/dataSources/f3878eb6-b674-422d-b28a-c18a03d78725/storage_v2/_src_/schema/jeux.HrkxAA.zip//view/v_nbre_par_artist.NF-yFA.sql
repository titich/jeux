create view v_nbre_par_artist as
select `jeux`.`artist_jeu`.`artist`    AS `artist_id`,
       `jeux`.`artist`.`artist_nom_en` AS `artist_nom_en`,
       count(0)                        AS `nbre`
from ((`jeux`.`artist_jeu` left join `jeux`.`artist` on (`jeux`.`artist`.`artist_id` = `jeux`.`artist_jeu`.`artist`))
         left join `jeux`.`jeu` on (`jeux`.`jeu`.`jeu_id` = `jeux`.`artist_jeu`.`jeu`))
where `jeux`.`jeu`.`jeu_bgg_subtype` = 'boardgame'
group by `jeux`.`artist_jeu`.`artist`, `jeux`.`artist`.`artist_nom_en`
order by count(0) desc;

